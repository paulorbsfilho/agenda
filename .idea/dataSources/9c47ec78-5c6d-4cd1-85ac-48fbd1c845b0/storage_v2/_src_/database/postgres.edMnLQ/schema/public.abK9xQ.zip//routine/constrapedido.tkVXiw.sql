create function constrapedido() returns trigger
  language plpgsql
as
$$
DECLARE
fornecedor_id INTEGER;
pedido_id INTEGER;
BEGIN
	SELECT COD_FORNECEDOR FROM FORNECEDOR WHERE COD_FORNECEDOR = NEW.cod_fornecedor INTO fornecedor_id;
	SELECT COD_PEDIDO FROM PEDIDO WHERE COD_PEDIDO = NEW.cod_pedido INTO pedido_id;
	IF  fornecedor_id IS NULL THEN
		RAISE EXCEPTION 'O codigo de fornecedor % não existe', NEW.cod_fornecedor;
	END IF;
	IF pedido_id > 0 THEN
		RAISE EXCEPTION 'O codigo do pedido  % ja existe.', NEW.cod_pedido;
	END IF;
	IF NEW.cod_pedido IS NULL  THEN
		RAISE EXCEPTION 'O codigo do pedido não pode ser null.';
	END IF;
	IF NEW.data_pedido IS NULL  THEN
		RAISE EXCEPTION 'A data do pedido não pode ser null.';
	END IF;
	RETURN NEW;
END;
$$;

alter function constrapedido() owner to admin;

