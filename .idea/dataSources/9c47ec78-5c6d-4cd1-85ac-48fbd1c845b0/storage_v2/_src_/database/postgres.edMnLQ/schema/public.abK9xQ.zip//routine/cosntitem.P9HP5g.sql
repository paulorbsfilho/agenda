create function cosntitem() returns trigger
  language plpgsql
as
$$
DECLARE
livro_id INTEGER;
pedido_id INTEGER;
primary_id INTEGER;
BEGIN
	SELECT COD_LIVRO FROM LIVRO WHERE COD_LIVRO = NEW.cod_livro INTO livro_id;
	SELECT COD_PEDIDO FROM PEDIDO WHERE COD_PEDIDO = NEW.cod_pedido INTO pedido_id;
	SELECT COD_PEDIDO FROM ITEM_PEDIDO WHERE COD_LIVRO = NEW.cod_livro AND COD_PEDIDO = NEW.cod_pedido INTO primary_id;
	IF livro_id IS NULL THEN
		RAISE EXCEPTION 'O codigo do livro % não existe.', NEW.cod_livro;
	END IF;
	IF pedido_id IS NULL THEN
		RAISE EXCEPTION 'O codigo do pedido % não existe.', NEW.cod_pedido;
	END IF;
	IF primary_id IS NOT NULL THEN
		RAISE EXCEPTION 'A chave primaria COD_LIVRO(%) + COD_PEDIDO(%) já existe.', NEW.cod_livro, NEW.cod_pedido;
	END IF;
	IF NEW.quantidade_item <= 0 THEN
		RAISE EXCEPTION 'A quantidade não pode ser menor que 1.';
	END IF;
	IF NEW.quantidade_item IS NULL THEN
		RAISE EXCEPTION 'A quantidade não pode ser null.';
	END IF;
	RETURN NEW;
END;
$$;

alter function cosntitem() owner to admin;

