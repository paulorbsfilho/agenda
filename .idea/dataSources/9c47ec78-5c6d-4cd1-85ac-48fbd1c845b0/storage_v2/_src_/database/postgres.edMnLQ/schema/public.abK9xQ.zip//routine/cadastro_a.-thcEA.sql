create function cadastro_a() returns trigger
  language plpgsql
as
$$
BEGIN
  IF NEW.NOME NOT LIKE '1%'
  THEN
    INSERT INTO ALUNO(NOME) VALUES (NEW.NOME);
  END IF;
  RETURN NEW;
END
$$;

alter function cadastro_a() owner to admin;

